#include <kipr/wombat.h>

void line_follow() { 
		// code for following a line
}
		// change from digital to analog
void move_to_airlock() {
    while(digital(0)==0) { 
        motor(0,200);
        motor(1,200);
        break;
    }
    if (digital(0)==1) { 
        int idealdistance = x
        while (distance_sensor_detection <= x) {// substitute distance_sensor_detection with correct function
        	motor(0,-50);
        	motor(1,50);
        	// turn until distance is = idealdistance
        }
   	    while (distance_sensor_detection <= y) {
        	int idealdistance2 = y;
        	motor(0,200);
        	motor(1,200);
            break;
            // move forward until distance = y
        }
        
       	msleep(5000) // wait 5 seconds while arm configures itself
        
        motor(0,-100);
        motor(1,-100); //reversing while arm gripped airlock
        
        
        msleep(2000) // break for gripper to release itself
        
        
        
        motor(0,-100);
        motor(1,-100); //moving back few steps

        void move_to_poms() {
        motor(0,100);
        motor(1,-100); // turning towards black line coming out of moon base
        
            
    	  while (digital(0) == 0) { // moving foward until sensor detects black line
          	motor(0,100);
            motor(1,100);
            break;
          }
        
        line_follow() // write actual code later, it will follow the line
            
        motor(0,-100);
        motor(1,100);
        msleep(1000); // for robot to turn 90 degrees
        
        motor(0,100);
        motor(1,100);
        msleep(1000) // for robot to move forward into center of area 3 and prepare for pom sorting
            
        motor(0,-100);
        motor(1,100); // turn towards poms
        }
    }
    }
}



int main()
{
    
    shut_down_in(4);
    move_to_airlock();
    return 0;
}




/*

Psuedocode:

only run if time < 119
begin

task 1 open_airlock

move forward until black line is detected
turn 'x' degrees
move until distance = 'a'
close gripper ( grab airlock )
reverse motors
release gripper
square up 

task 2 sort_poms

move into area 3 facing poms ( i create won't be at moon base yet)
grab red pom
move forward
drop red pom
drag green poms back

grab green pom 
move backward
drop green pom
drag red poms forward
sqaure up

(remember that this task requires styrofoam)

if time enables... 

task 3 collect_purple_noodles

move to bottom of area 3
drive forward 
move gripper to floor-level 
continue driving
sweep the pool noodles foward w/ robot
continue driving until 'y' distance from lava tube area
grab pool noodles
drop in lava tube area (ensure they are touching ground (rub mechanism) )
try again just in case missed one ( the side peices will keep it in range )
square up 

and/or (time based)

task drag_and_drop astronauts and return_home

pick up astronauts from pre-set location
drive them to airlock
pick up as many as possible, lift arm
drop

attempt 2 of pick-up/drop

close airlock


return home


*/
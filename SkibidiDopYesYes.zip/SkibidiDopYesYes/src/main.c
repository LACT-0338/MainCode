#include <kipr/wombat.h>
void smooth_servo(int port, int position) {
 int current_position = get_servo_position(port);
 if(current_position < position) {
    while(current_position < position) {
        set_servo_position(port, current_position+10);
        msleep(10);
        printf("adjusted position %d \n", current_position);
        current_position = get_servo_position(port);
       
    }
 }
    else {
    while(current_position > position) {
        set_servo_position(port, current_position-10);
        msleep(10);
        printf("adjusated %d \n", current_position);
        current_position = get_servo_position(port);
    }
    }
}
int main()
{
    enable_servos();
    smooth_servo(0,1200);
 
    
    printf("slowed down \n");
    return 0;
    
}

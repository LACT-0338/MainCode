#include <kipr/wombat.h>


void move_to_poms() {
   while(analog(1)<1500) { // tophat sensor  
       
        motor(0,400);
        motor(1,400);
   }
   
   motor(0, 100); // move towards first pom 
   msleep(200);
   motor(1, 100);
   msleep(200);
} 
   // moving towards first set of poms and turning
   void turn1() { 
   motor(0,-100);
   motor(1,100); 
   msleep(900);
   }
   // moving towards second set of poms and turning 
 
   
   void turn2() {
   motor(0,100);
   motor(1,-100); 
   msleep(700);
   }

   void move_to_poms_two() {
   motor(0,100);
   msleep(100);
   motor(1,100);
   msleep(1000);
   }

   void turn3() { 
   motor(0,-100);
   motor(1,100);
   msleep(900);
   
   }
 
   void turn4() {
   motor(0,100);
   motor(1,-100);
   msleep(800);
   }

   void move_to_black_lines() {
       while(analog(1)<1500) { // tophat sensor  
        motor(0,400);
        motor(1,400);
       }
   }
   
   void reverse_slight() {
       
       motor(0,-400);
       motor(1,-400);
       msleep(300);
   }    
   void reverse_extreme() {
       while(analog(1)<1500) {
          motor(0,-600);
       	  motor(1,-600);
       }
   }       
    

int main()
{
    move_to_poms();
    turn1();
    motor(0,0);
    motor(1,0);
    msleep(2000);
    turn2();
    move_to_poms_two();
    turn3();
    motor(0,0);
    motor(1,0);
    msleep(2000);
    turn4();
    move_to_black_lines();
    reverse_slight();
    reverse_extreme();
              
    
    return 0;
}


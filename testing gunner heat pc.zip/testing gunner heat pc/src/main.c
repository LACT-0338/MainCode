#include <kipr/wombat.h>


void move_to_poms() {
    enable_servos();
    set_servo_position(0,1080);
    set_servo_position(1,1500);
   while(analog(1)<1500) { // tophat sensor  
       
        motor(0,400);
        motor(1,400);
   }
   
   motor(0, 100); // move towards first pom 
   msleep(180);
   motor(1, 100);
   msleep(180);
} 
   // moving towards first set of poms and turning
   void turn1() { 
      cmpc(0);
      cmpc(1);
   while(gmpc(0) > -1050) {
      motor(1,100);
      motor(0,-100);   
      printf("%d \t", gmpc(0));  \
   }
       motor(0,0);
       motor(1,0);
        set_servo_position(0,1900);
       msleep(100);
       motor(1,-100);
       motor(0,-100);
       msleep(500);
       set_servo_position(0,2000);
       msleep(100);
        motor(1,100);
       motor(0,100);
       msleep(500);
       set_servo_position(1,1850);
       motor(1,0);
       motor(0,0);

   cmpc(0);
   cmpc(1);
   motor(0,0);
   motor(1,0);
   msleep(1000);
   while(gmpc(0)<1050) {
  
    motor(1,-100);
    motor(0,100);
        printf("%d", gmpc(0));

   }
  motor(1,0);
  motor(0,0);
  
   }

void turn2() {
 motor(1,100);
 motor(0,100);
 msleep(1500);   
motor(0,0);
motor(1,0);
cmpc(0);
cmpc(1);
while(gmpc(0)>-1050) {
    motor(0,-100);
    motor(1,100);
}

    motor(0,0);
    motor(1,0);
    msleep(1000);
while(gmpc(0)<0) {
    motor(0,100);
    motor(1,-100);
}
cmpc(1);
  cmpc(0);
    motor(0,0);
    motor(1,0);
    msleep(100);
   
    
}

void go_airlock() {
 while(analog (1) < 2500){
  motor(1,-100);
  motor(0,-100);
 }
  msleep (100);
  motor(1,0);
  motor(0,0);
  msleep(100);

 cmpc(0);
cmpc(1);
while(gmpc(0)<500) {
    motor(0,100);
    motor(1,-100);
}
    motor(0,0);
    motor(1,0);
    msleep(100);
    int red;
        red = analog(0);
 while(red== 1530) {
        motor(1,100);
        motor(0,100);
       
} motor(0,0);
    motor(1,0);
    msleep(100);
}
    
    
int main()
{
    move_to_poms();
    turn1();
    turn2();
     go_airlock();
    
    return 0;
}


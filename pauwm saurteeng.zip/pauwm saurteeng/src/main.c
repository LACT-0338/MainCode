#include <kipr/wombat.h>


void move_to_poms() {
    enable_servos();
    set_servo_position(0,1080);
    set_servo_position(1,1442);
   while(analog(1)<1500) { // tophat sensor  
       
        motor(0,400);
        motor(1,400);
   }
   
   motor(0, 100); // move towards first pom 
   msleep(180);
   motor(1, 100);
   msleep(180);
} 
   // moving towards first set of poms and turning
   void turn1() { 
      cmpc(0);
      cmpc(1);
   while(gmpc(0) > -1050) {
      motor(1,100);
      motor(0,-100);   
   } }

	void allahuakbar() {
       motor(0,0);
       motor(1,0);
        set_servo_position(0,1600);
       msleep(100);
       motor(1,-100);
       motor(0,-100);
       msleep(1000);
       set_servo_position(0,1960);
       msleep(500);
        motor(1,100);
       motor(0,100);
       msleep(1000);
       set_servo_position(1,1804);
       msleep(300);
       set_servo_position(0,1200);
       motor(1,0);
       motor(0,0);
    }

 void grippin1() {
   cmpc(0);
   cmpc(1);
   motor(0,0);
   motor(1,0);
   msleep(1000);
   motor(1,100);
   motor(0,100);
   msleep(700);
   motor(1,0);
   motor(0,0);
   msleep(100);
 }
	void disengage1() {
   set_servo_position(1,873);
    printf(" \n disengaged");
       msleep(300);
       set_servo_position(0,2047);
       printf(" \n ready to push red poms");
       msleep(1000);
       printf("\n returning...");
   motor(1,-100);
       motor(0,-100);
       msleep(1200);
       motor(1,0);
       motor(1,0);
       msleep(50);
       set_servo_position(0,1400);
       printf(" \n turning to next pom");
    }
	void turnaway(){
   while(gmpc(0)<425) {
  
    motor(1,-100);
    motor(0,100);

   }
  motor(1,0);
  motor(0,0);
  msleep(100);
  set_servo_position(1,1300);
   }



int main()
{
    move_to_poms();
    turn1();
    allahuakbar();
    grippin1();
    disengage1();
    turnaway();
    return 0;
}